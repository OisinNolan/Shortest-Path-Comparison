/*
public class Main {
	public static void main(String[] args) {
		CompetitionFloydWarshall cfw = new CompetitionFloydWarshall("input-A.txt", 51, 70, 88);
		CompetitionDijkstra cd = new CompetitionDijkstra("input-A.txt", 51, 70, 88);
		System.out.println(cfw.timeRequiredforCompetition());
		System.out.println(cd.timeRequiredforCompetition());
	}
}
*/