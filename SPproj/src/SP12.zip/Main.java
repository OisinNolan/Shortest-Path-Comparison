/*
public class Main {
	public static void main(String[] args) {
		CompetitionFloydWarshall cfw = new CompetitionFloydWarshall("input-I.txt", 72,70,65);
		CompetitionDijkstra cd = new CompetitionDijkstra("input-I.txt", 72,70,65);
		System.out.println(cfw.timeRequiredforCompetition());
		System.out.println(cd.timeRequiredforCompetition());
	}
}
*/