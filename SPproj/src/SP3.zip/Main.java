
public class Main {
	public static void main(String[] args) {
		CompetitionFloydWarshall cfw = new CompetitionFloydWarshall("input-K.txt", 51, 70, 88);
		CompetitionDijkstra cd = new CompetitionDijkstra("input-K.txt", 51, 70, 88);
		System.out.println(cfw.timeRequiredforCompetition());
		System.out.println(cd.timeRequiredforCompetition());
	}
}